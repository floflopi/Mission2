package ui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.util.Arrays;
import java.awt.event.KeyAdapter;

public class FriendUI extends Window {

    private String friend_name="write the username of the friend you want to add...";
    private JFrame frame;
    private JTextField friendNameField;
    private JButton sendRequestButton;
    private JLabel friendsLabel;
    private JPanel friendsPanel;

    private JPanel topPanel;
    public FriendUI() {
        super("Friend UI"); // Vous pouvez ajuster la taille du cadre selon vos besoins
        this.frame = super.getFrame();
        initializeUI();
    }
    private void createTopPanel(){
        topPanel = new JPanel();
        topPanel.setBackground(getblackColor());
        topPanel.setPreferredSize(new Dimension(frame.getWidth(),100));
        
        friendNameField = new JTextField();
        friendNameField.setPreferredSize(new Dimension(frame.getWidth() * 2/3,40));
        Font newFont = new Font("SansSerif", Font.PLAIN,30); // Ajuster la taille de la police
        friendNameField.setFont(newFont);
        friendNameField.setForeground(Color.GRAY);
        friendNameField.setCaretPosition(0); // position curseur
        friendNameField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (friendNameField.getText().equals(friend_name)) {
                    friendNameField.setText("");
                    friendNameField.setForeground(Color.BLACK);
                }
            }
        });
        friendNameField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                // curseur au début si aucun mot de passe
                if (friendNameField.getText().equals(friend_name)){
                    friendNameField.setCaretPosition(0);
                }
            }
            @Override
            public void focusLost(FocusEvent e) {
            }
        });

        sendRequestButton = new JButton("Send Friend Request");
        sendRequestButton.setPreferredSize(new Dimension(frame.getWidth()/5,40));
        topPanel.add(friendNameField);
        topPanel.add(sendRequestButton);

        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
    }
    private void initializeUI() {
        createTopPanel();
        // Créer les composants
        friendsLabel = new JLabel("Amis : ");
        friendsPanel = new JPanel();

        // Ajouter un gestionnaire de disposition au panneau principal
        //frame.setLayout(new BorderLayout());



        // Ajouter les composants au panneau principal
        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(friendsLabel, BorderLayout.CENTER);
        frame.add(friendsPanel, BorderLayout.SOUTH);

        // Mettre à jour l'interface utilisateur
        updateUI();
    }
}
